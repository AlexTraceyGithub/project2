let rowOne = prompt('Write the first row');
let rowTwo = prompt('Write the second row');
let rowThree = prompt('Write the third row');

alert(`${rowOne} ${rowTwo} ${rowThree}`);


let number = 55555;
let newNumber = String(number).replaceAll('', ' ').trim();

console.log(newNumber);
